Kildekodemappe for øving  1
===========================