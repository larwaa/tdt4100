package encapsulation;

public class Account {
	
	// hindre direkte tilgang til balance og interestRate
	// tjenesteorientert / dataorientert
	private int balance, interestRate;

	public Account(int balance, int interestRate) {
		setInterestRate(interestRate);
		checkNegative(balance);
		this.balance = balance;
	}
	
	public double getBalance() {
		return this.balance;
	}
	
	public double getInterestRate() {
		return this.interestRate;
	}
	
	public void setInterestRate(int interestRate) {
		// feil ved negative tall
		checkNegative(interestRate);
		this.interestRate = interestRate;
	}
	
	public void deposit(int d) {
		// feil ved negative tall
		checkNegative(d);
		this.balance += d;
	}
	
	public void withdraw(int w) {
		// feil dersom du tar ut mer penger enn du har
		if (this.balance - w < 0) {
			throw new IllegalArgumentException();
		}
		// feil ved negative tall
		checkNegative(w);
		this.balance -= w;
	}
	
	public void addInterest() {
		this.balance *= (1 + this.interestRate/100);
	}
	
	//lagt til en sjekk for negative tall, som går igjen.
	private void checkNegative(int i) {
		if (i < 0) {
			throw new IllegalArgumentException("Negative tall er ugyldige.");
		}
	}
	
}
